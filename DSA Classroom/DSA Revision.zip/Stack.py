s = "[())]"
arr = []

balanced = True

for ch in s:
    if ch in "([{":
        arr.append(ch)
    else:
        if not arr:
            balanced = False
            break

        if (ch == ')' and arr[-1] == '(') or (ch == ']' and arr[-1] == '[') or(ch == '}' and arr[-1] == '{'):
            arr.pop()
        else:
            balanced = False
            break

# After loop, check if stack is empty
if arr:
    balanced = False

print(balanced)
