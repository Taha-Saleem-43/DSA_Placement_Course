def tricky_recursion(n):
    if n == 0:
        return
    print(n, end=' ')   # 3 3 2 2 1 1 
    tricky_recursion(n-1)
    tricky_recursion(n-1)

# Call the function
tricky_recursion(3)