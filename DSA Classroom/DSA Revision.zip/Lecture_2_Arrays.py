# Worst Solution
n=5 # 1 - 5
arr=[2,3,1,5]
counter = 1
for i in range(len(arr)):
    if counter not in arr:
        print("Missing_value:",counter)
    counter += 1


# Find missing number from 1 to N
N=5
arr=[1,2,3,5]
arr2=[2, 3, 1, 5]

#Since sum of first N natural numbers is N*(N+1)/2
temp= N*(N+1)//2 - sum(arr)         # O(1) Time Complexity and O(1) Space Complexity
print("Missing_value:",temp)


def bubble_sort(arr):
    n = len(arr)-1
    for i in range(n):               # Outer loop for passes
        for j in range(n - i):       # Inner loop for comparisons
            if arr[j] > arr[j + 1]:      # Swap if elements are in wrong order
                arr[j], arr[j + 1] = arr[j + 1], arr[j]

# Example
arr = [5, 3, 4, 1, 2] # -->[3,4,1,2,5]->5>3-->5>4-->5>1-->5>2
bubble_sort(arr)
print("Bubble Sort:", arr)

def selection_sort(arr):
    n = len(arr)
    for i in range(n):
        min_index = i
        for j in range(i + 1, n):
            if arr[j] < arr[min_index]:
                min_index = j
        # Swap the found minimum with the first unsorted element
        arr[i], arr[min_index] = arr[min_index], arr[i]

# Example
arr = [5, 3, 4, 1, 2]
selection_sort(arr)
print("Selection Sort:", arr)


def insertion_sort(arr):
    n = len(arr)
    for i in range(1, n):
        key = arr[i]      # element to be placed
        j = i - 1
        # Move elements greater than key one step ahead
        while j >= 0 and arr[j] > key:   
            arr[j + 1] = arr[j] 
            j -= 1
        arr[j + 1] = key

# Example
arr = [5, 3, 4, 1, 2]===>[3,5,4,1,2]-->[3,4,5,1,2]-->[1,3,4,5,2]-->[1,2,3,4,5]
insertion_sort(arr)
print("Insertion Sort:", arr)


Input: s = "madam"
Output: True
# Two pointer technique to check palindrome
def is_palindrome(s):
    left, right = 0, len(s) - 1
    while left < right:
        if s[left] != s[right]:
            return False
        left += 1
        right -= 1
    return True


#Reverse an Array
arr=[1, 2, 3, 4, 5]
left=0
right=len(arr)-1
while left<right:
    arr[left],arr[right]=arr[right],arr[left]
    left+=1
    right-=1
print("Reversed Array:",arr)







