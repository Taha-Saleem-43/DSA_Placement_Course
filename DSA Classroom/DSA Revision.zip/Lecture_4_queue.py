# Problem
# Generate and print binary numbers from 1 to N using a queue.
# Input: N = 5
# Output: 1 10 11 100 101
from collections import deque
def generate_binary_numbers(n):
    q = deque()          # create an empty queue
    q.append("1")        # enqueue the first binary number
    result = []

    for _ in range(n):
        front = q.popleft()      # dequeue front element
        result.append(front)     # store or print it
        
        # Generate next two numbers and enqueue them
        q.append(front + "0")   #-->Q[]    #-->R[1,10,11,101,110]
        q.append(front + "1")

    return result

# Example usage
print(generate_binary_numbers(5))



# How to create a queue using deque built-in module
arr=[1,2,4,5,6]
from collections import deque
n = deque()
n.append(10)
n.append(20)
n.append(30)
print(n.popleft())  # behave as Queue
print(n.pop())      # behave as Stack    
    

# Implement a Stack(LIFO) using a Single Queue (FIFO) 
# Description:
# You need to implement a stack (LIFO) behavior using only one queue.
# Use standard queue operations only:
# enqueue(x)
# dequeue()
# size()
# isEmpty()

from collections import deque
class MyStack:
    def __init__(self):
        self.q = deque()

    def push(self, x):
        self.q.append(x) #-->[20,10,30]
        # Move all previous elements behind the new one
        for _ in range(len(self.q) - 1):
            self.q.append(self.q.popleft())  # Rotate the queue #--[30,20,10]

    def pop(self):
        return self.q.popleft() if not self.empty() else None

    def top(self):
        return self.q[0] if not self.empty() else None

    def empty(self):
        return len(self.q) == 0


# Example usage
stack = MyStack(10)
stack.push(10)
stack.push(20)
stack.push(30)
print(stack.top())   # 20
print(stack.pop())   # 20
print(stack.top())   # 10



# Circular Queue
# A Circular Queue is a fixed-size queue where the last position is connected back to the first position to make a circle.
# It efficiently uses memory by reusing empty spaces after dequeuing.

# Cicular Queue Implementation
class CircularQueue:
    def __init__(self, k):
        self.size = k
        self.queue = [None] * k
        self.front = 0
        self.rear = -1
        self.count = 0

    def enqueue(self, value):
        if self.isFull():
            print("Queue is full")
            return False
        
        self.rear = (self.rear + 1) % self.size
        self.queue[self.rear] = value
        self.count += 1
        return True

    def dequeue(self):
        if self.isEmpty():
            print("Queue is empty")
            return False
        
        value = self.queue[self.front]
        self.queue[self.front] = None
        self.front = (self.front + 1) % self.size
        self.count -= 1
        return value

    def Front(self):
        return -1 if self.isEmpty() else self.queue[self.front]

    def Rear(self):
        return -1 if self.isEmpty() else self.queue[self.rear]

    def isEmpty(self):
        return self.count == 0

    def isFull(self):
        return self.count == self.size

    def display(self):
        print("Queue:", self.queue)
        
    cq = CircularQueue(3)
    cq.enqueue(10)  # [10, None, None]
    cq.enqueue(20)  # [10, 20, None]
    cq.enqueue(30)  # [10, 20, 30]
    cq.dequeue()    # removes 10 → [None, 20, 30]
    cq.enqueue(40)  # rear wraps around → [40, 20, 30]
    cq.display()



# To DOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOOO
# Implement a Queue(FIFO) using a Stack(LIFO) 

