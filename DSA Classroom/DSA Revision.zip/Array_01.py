# nums = [0, 1, 0, 3, 12]
# ls = []
# zerocounter = 0

# for i in range(len(nums)):
#     if nums[i] != 0:
#         ls.append(nums[i])
#     else:
#         zerocounter += 1

# for j in range(zerocounter):
#     ls.append(0)

# nums = [0, 1, 0, 3, 12]
# front = 0

# for i in range(len(nums)):
#     if nums[i] != 0:
#         nums[front] = nums[i]
#         nums[i] = 0
#         front += 1
        
# print(nums)

nums = [0, 1, 0, 3, 12]
maxi = len(nums) - 1             # O(n)
                                # O(1)

for i in range(int(len(nums)/2)):
    temp = nums[maxi]
    nums[maxi] = nums[i]
    nums[i] = temp
    maxi -= 1

print(nums)


    
    
            
            
    

    

        
        
    



