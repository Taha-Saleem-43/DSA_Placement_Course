# Binary Search Implementation
def binary_search(arr, target):
    low = 0
    high = len(arr) - 1
    
    while low <= high:
        mid = low + (high - low) // 2  # Avoid overflow
        if arr[mid] == target:
            return mid
        elif arr[mid] < target:
            low = mid + 1
        else:
            high = mid - 1
    return -1  # Target not found

# Example usage
arr = [2, 4, 6, 8, 10, 12 , 13] 
target = 8
print(binary_search(arr, target))  # Output: 3


# Recursion
def tricky_recursion(n):
    if n == 0:
        return
    print(n, end=' ')   # 3 3 2 2 1 1 
    tricky_recursion(n-1)
    tricky_recursion(n-1)

# Call the function
tricky_recursion(3)
# Output: 3 2 1 1 2 1 1
