# Basic Heaapq Example
import heapq

pq = []
heapq.heappush(pq, (2, "Code"))
heapq.heappush(pq, (1, "Sleep")) 
heapq.heappush(pq, (3, "Eat"))

while pq:
    priority, task = heapq.heappop(pq) # heapq.heappush(pq, (-priority, value))
    print(priority, task) 
    

# Functions of heapq 
import heapq

# create an empty heap
heap = []

# add elements
heapq.heappush(heap, (3, "Code"))
heapq.heappush(heap, (1, "Sleep"))
heapq.heappush(heap, (2, "Eat"))

print("Heap:", heap)

# remove smallest (priority=1)
print("Pop:", heapq.heappop(heap))

# push then pop smallest (in one go)
print("PushPop:", heapq.heappushpop(heap, (0, "NewTask")))

# replace smallest then push new item
print("Replace:", heapq.heapreplace(heap, (4, "Update")))
print(heap)

# convert list to heap
nums = [5, 3, 8, 1, 2]
heapq.heapify(nums)
print("Heapified:", nums)

# get top elements
print("3 smallest:", heapq.nsmallest(3, nums))
print("2 largest:", heapq.nlargest(2, nums))


import heapq
nums = [3, 2, 1, 5, 6, 4]
k = 2
heapq.heapify(nums)
print(nums)
print(heapq.nlargest(k,nums)[-1])  #(O(nlogn))

k = 4
nums = [3, 2, 1, 5, 6, 4]
nums.sort(reverse=True)
print(nums[k-1])    #(O(nlogn)) Sorting

#(O(nlogk)) where k<<n
import heapq
nums = [3, 2, 1, 5, 6, 4]
k = 2
heap = []
for n in nums:
    heapq.heappush(heap, n)
    if (len(heap)>k):
        heapq.heappop(heap)
    
print( heapq.heappop(heap)) 


# K Closest Numbers to X (LeetCode #658 variant)
# Problem:
# Given an array and a number x, find k numbers closest to x.

import heapq
# Output: [6, 7, 8]
arr = [5, 6, 7, 8, 9] #-->[-1, 0, -1]
k = 3
x = 7

max_heap = []
for num in arr:
    heapq.heappush(max_heap, (-abs(num - x), num))
    if len(max_heap) > k: 
        heapq.heappop(max_heap)
        
result = []
while max_heap:
    result.append(heapq.heappop(max_heap)[1])
    
print(sorted(result))

# Given an integer array nums and an integer k
# return the k most frequent elements.
# from collections import Counter
# Counter is a special type of dictionary return 2 things num, count

nums = [1,1,1,2,2,3]
k = 2
# Output:
# [1,2]

from collections import Counter
import heapq
count = Counter(nums) #{1: 3, 2: 2, 3: 1}
min_heap = []

for num, freq in count.items():
    heapq.heappush(min_heap, (freq, num))
    if len(min_heap) > k:
        heapq.heappop(max_heap)

result = []
while min_heap:
    result.append(heapq.heappop(min_heap)[1])
    



    
    
    
    






 
