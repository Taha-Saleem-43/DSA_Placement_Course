nums1 = [2, 3 , 0 , 0, 0, 0]   # length = m + n
m = 3                        # valid elements in nums1  # Medium Level
nums2 = [2, 2, 2, 4] 
n = 3

k = m + n - 1 
i = m - 1
j = n - 1
while i > 0 and j > 0:
    if  nums1[i]>nums2[j]:
        nums1[k] = nums1[i]
        i -= 1
    else:
        nums1[k] = nums2[j]
        j -= 1
    k -= 1
    
#Copy remainin elements of nums2
while j >= 0:
    nums1[k] = nums2[j]
    j -=1
    k -=1

#Copy remaining elements of nums1
while i >= 0:
    nums1[k] = nums1[i]
    i -=1
    k -= 1

    
        
    
from  collections import Counter
nums = [1,2,2,3,4,4,4,5,5]
n=Counter(nums)
print(n)


def two_sum(nums, target):
    hashmap = {}  # value → index
    for i, num in enumerate(nums):
        complement = target - num
        if complement in hashmap:
            return [hashmap[complement], i]
        hashmap[num] = i









