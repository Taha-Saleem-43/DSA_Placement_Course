n=set([1,2,3])    # Sets do not allow duplicate values 
n.add(6)              # Unordered collection of unique elements
n.remove(2)
n.discard(8)    # Does not raise an error if element not found
print(n)

# Set operations
a=set([1,2,3,4])
b=set([3,4,5,6])
print(a-b)   # Difference
print(a|b)   # Union
print(a&b)   # Intersection

# 1.LeetCode #217
# Description:
# Given an integer array nums, return True if any value appears at least twice, otherwise False.
# Input: nums = [1, 2, 3, 1]
# Output: True
nums=[1,2,3,4,5,1]
print(len(nums)!=len(set(nums)))


# 2.LeetCode #349
# Description:
# Given two integer arrays, return an array of the element that is unique in their own array but common on both.
# Input: nums1 = [1,2,2,1], nums2 = [2,2]
# Output: [2]
nums1 = [1,2,2,1]
nums2 = [2,2]
print(list(set(nums1) & set(nums2))) # & used for intersection


# 3.LeetCode #929
# Description:
# Every email has a local name and domain name, separated by @.
# Ignore everything after + in the local name.
# Ignore . in the local name.
# Return count of unique emails.
# Input: ["test.email+alex@leetcode.com", "test.e.mail+bob@leetcode.com", "testemail+david@lee.tcode.com"]
# Output: 2

emails = ["test.email+alex@leetcode.com", "test.e.mail+bob@leetcode.com", "testemail+david@lee.tcode.com"]
for i in range(len(emails)):
    local,domain = emails[i].split('@') # Split into local and domain
    var = local.split('+')[0].replace('.','')   # Process local name
    emails[i] = var + '@' + domain # Reconstruct email
    
print(emails)
print(set(emails))

# To Dooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooooo
# LeetCode #202
# Description:
# A number is happy if repeatedly summing the squares of its digits eventually equals 1.
# If it loops endlessly (never reaches 1), it’s not happy.
# Input: n = 19
# Output: True
# # 1² + 9² = 82 → 8² + 2² = 68 → 6² + 8² = 100 → 1² = 1

